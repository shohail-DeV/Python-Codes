x = int(input("Enter x "))
a=x
x+=x+10
print(x)
x=a
x=x+10
print(x)