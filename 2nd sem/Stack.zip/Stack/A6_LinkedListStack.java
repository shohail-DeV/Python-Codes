package Stack;

import java.util.Scanner;

class A6_LinkedListStack
 {
	Node top;
	void push(int ele)
	{
		Node p=new Node();
		p.info=ele;
		p.link=null;
		p.link=top;
		top=p;
	}
	void pop()
	{
		if(top==null)
		{
			System.out.println("Underflow");
			return;
		}
		else if(top.link==null)
			top=null;
		else {
		Node p=top;
		top=top.link;
		p.link=null;
		}
	}
	void display()
	{
		System.out.println("Top"+top);
		Node p=top;
		while(p!=null)
		{
			System.out.println(p.info+" "+p.link);
			p=p.link;
		}	
	}
}
 

	
	

/*
 * package Stack;

import java.util.Scanner;

class Node {
int info;
Node link;
	}


class Stack1 {
	Node top;
	void push(int ele)
	{
		Node p=new Node();
		p.info=ele;
		p.link=null;
		p.link=top;
		top=p;
	}
	void pop()
	{
		if(top==null)
		{
			System.out.println("Underflow");
			return;
		}
		else if(top.link==null)
			top=null;
		else {
		Node p=top;
		top=top.link;
		p.link=null;
		}
	}
	void display()
	{
		System.out.println("Top"+top);
		Node p=top;
		while(p!=null)
		{
			System.out.println(p.info+" "+p.link);
			p=p.link;
		}	
	}
}
 class A6_LinkedListStack {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
Stack1 l1= new Stack1();
l1.display();
int num;
while(true) {
	System.out.println("*********MENU*****");
	System.out.println("0. Exit");
	System.out.println("1. Display");
	System.out.println("2. Push");
	System.out.println("3. Pop");
	System.out.println("Enter Your choice");
	num=sc.nextInt();
	switch(num)
	{
	case 0:
		return;
	case 1:l1.display();
break;
	case 2:
	System.out.println("Enter info ");
	int ele=sc.nextInt();
	l1.push(ele);
	break;
	case 3:l1.pop();
	break;
	default:System.out.println("Wrong Choice");
	break;
}
	}}
	}
	*/



