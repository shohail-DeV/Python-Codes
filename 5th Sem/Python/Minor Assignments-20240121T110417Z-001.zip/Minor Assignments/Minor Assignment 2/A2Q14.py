def UpperCase(str):
    assert str.islower()
    print(str.upper())
if __name__=='__main__':
    UpperCase(input("Enter lowercase alphabet"))