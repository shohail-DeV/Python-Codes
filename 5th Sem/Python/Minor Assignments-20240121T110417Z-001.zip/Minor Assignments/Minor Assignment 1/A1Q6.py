'''= is an assignment operator
== is an equality operator'''
x=10
y=20
z=20
print(x==y)
print(y==z)

'''/ is a division operator
% is a modulus operator'''
print(10/5)
print(10%5)

'''/ is a division operator
// is a floor division operator'''
print(9/5)
print(9//5)

'''* is a multiplication operator
** is a xxponentiation operator'''
print(10*2)
print(10**2)