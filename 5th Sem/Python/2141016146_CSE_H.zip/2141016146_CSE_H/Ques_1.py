#Creating a function
def binary_to_decimal(binary):
    decimal = 0
    power = len(binary) - 1
    
    for digit in binary:
        decimal += int(digit) * (2 ** power)
        power -= 1
    
    return decimal


#taking user input
binaryNumber = input("Enter a binary number: ")

if set(binaryNumber).issubset({'0', '1'}):
    decimal_number = binary_to_decimal(binaryNumber)
    print(f"The decimal equivalent of {binaryNumber} is: {decimal_number}")
else:
    print("Please enter a valid binary number (containing only 0s and 1s).")
