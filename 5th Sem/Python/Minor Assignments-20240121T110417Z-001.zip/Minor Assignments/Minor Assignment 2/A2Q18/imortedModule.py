def test1():
    print('test1 in imported module')
def test2():
    print('test2 in imported module')
test1()
test2()