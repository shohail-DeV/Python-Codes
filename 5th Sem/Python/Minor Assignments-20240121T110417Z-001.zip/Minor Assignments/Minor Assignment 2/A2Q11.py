def evaluate():
    print(eval(input("Enter an arithmetic expression: ")))
evaluate()