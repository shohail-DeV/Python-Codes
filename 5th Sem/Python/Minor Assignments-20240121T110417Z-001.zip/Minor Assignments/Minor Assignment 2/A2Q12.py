'''The default return value of fuction is always be None .'''
def fun():
    pass
a=fun()
print(a)