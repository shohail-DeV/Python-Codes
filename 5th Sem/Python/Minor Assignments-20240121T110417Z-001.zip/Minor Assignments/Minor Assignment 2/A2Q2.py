import random
x=random.random()+5
print(x)