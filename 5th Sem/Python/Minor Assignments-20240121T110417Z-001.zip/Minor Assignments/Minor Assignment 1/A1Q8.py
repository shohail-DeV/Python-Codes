marks=int(input("Enter marks "))
if(marks>300 and marks<400):
    print("True")
letter=(input("Enter Character "))
if(letter.isupper()):
    print("True")
post=(input("Enter Post "))
experince=int((input("Enter experince year ")))
if(post == 'engineer' and experince>4):
    print("True")