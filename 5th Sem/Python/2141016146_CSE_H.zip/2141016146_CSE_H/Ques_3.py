def to_base_10(number, base):
    return int(number, base)

def from_base_10(number, base):
    alphabet = "0123456789ABCDEF"
    if number == 0:
        return '0'
    result = ''
    while number > 0:
        digit = number % base
        result = alphabet[digit] + result
        number //= base
    return result

def main():
    try:
        input_base = int(input("Enter the base of the input number (between 2 and 16): "))
        if input_base < 2 or input_base > 16:
            print("Error: Base should be between 2 and 16.")
            return

        input_number = input(f"Enter a number in base {input_base}: ")

        target_base = int(input("Enter the base to convert to (between 2 and 16): "))
        if target_base < 2 or target_base > 16:
            print("Error: Base should be between 2 and 16.")
            return

        decimal_number = to_base_10(input_number, input_base)
        result_number = from_base_10(decimal_number, target_base)

        print(f"The number {input_number} in base {input_base} is {result_number} in base {target_base}")

    except ValueError:
        print("Error: Please enter a valid number.")

if __name__ == "__main__":
    main()
