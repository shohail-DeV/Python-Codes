def printSum(n):
    s=0
    for i in n:
        s=s+int(i)
    print (s)
n=input("Enter the number")
printSum(n)