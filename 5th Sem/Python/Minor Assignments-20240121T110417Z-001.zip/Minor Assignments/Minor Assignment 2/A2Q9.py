def say (message, times=2):
    print(message*times)
say ('Hello')
say('World',5)

def fun(a=2,b=3,c=7):
    d= a+b+c
    print(d)
print(fun(2))