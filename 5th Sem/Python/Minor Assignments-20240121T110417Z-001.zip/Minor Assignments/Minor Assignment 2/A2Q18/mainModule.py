import imortedModule as i
print('hello')