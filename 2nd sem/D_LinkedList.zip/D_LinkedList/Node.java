package D_LinkedList;

public class Node {
int info;
Node link;
Node prev;
	}

