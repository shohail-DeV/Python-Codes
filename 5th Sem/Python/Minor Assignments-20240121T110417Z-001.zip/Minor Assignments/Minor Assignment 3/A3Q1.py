marks=int(input("Enter the marks -> "))
print({True: "good", False: "average"} [marks >= 70])