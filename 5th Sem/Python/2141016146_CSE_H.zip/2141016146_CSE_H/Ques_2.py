def hex2int(hex_digit):
    hex_digit = hex_digit.lower()
    if hex_digit.isdigit():
        return int(hex_digit)
    elif hex_digit.isalpha() and len(hex_digit) == 1 and 'a' <= hex_digit <= 'f':
        return ord(hex_digit) - ord('a') + 10
    else:
        print("Error: Input is not a valid hexadecimal digit.")
        

def int2hex(decimal_digit):
    if 0 <= decimal_digit <= 9:
        return str(decimal_digit)
    elif 10 <= decimal_digit <= 15:
        return chr(ord('A') + decimal_digit - 10)
    else:
        print("Error: Input is outside the expected range (0-15).")
        


hexadecimal_digit = input("Enter a hexadecimal digits\n")
decimal_integer = hex2int(hexadecimal_digit)
print(f"The decimal equivalent of {hexadecimal_digit} is: {decimal_integer}")

decimal_number = int(input("Enter a decimal number\n"))
hexadecimal_digit = int2hex(decimal_number)
print(f"The hexadecimal equivalent of {decimal_number} is: {hexadecimal_digit}")
