/*Authors Name:Debraj Mandal
 *Registration No:2141013068
 *Date:18/07/2022
 *Program Description:Array Representation of Stack
 */
package Stack;

class Stack{
	int TOP;
	int stk[];
	final int MAX=5;
	Stack(){
		TOP=-1;
		stk=new int[MAX];
	}
	boolean isFull() {
		if(TOP==MAX-1)
			return true;
		else 
			return false;
	}
	boolean isEmpty()
	{
		if(TOP==-1)
			return true;
		else 
			return false;
	}
	void PUSH(int element)
	{
		if(isFull())
		{
			System.out.println("Overflow");
			return;
		}
			TOP=TOP+1;
			stk[TOP]=element;
	}
	void POP() {
		if(isEmpty())
		{
			System.out.println("Underflow");
			return;
		}
		System.out.println("Element deleted is "+stk[TOP]);
		TOP=TOP-1;
	}
}
public class A6 {
public static void main(String[] args) {
	Stack s= new Stack();
	s.PUSH(10);
	s.PUSH(20);
	s.PUSH(30);
	s.POP();
	s.POP();
	s.POP();
	s.POP();
}
}
