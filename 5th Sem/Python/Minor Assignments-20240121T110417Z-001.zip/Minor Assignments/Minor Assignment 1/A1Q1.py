x=int(input("Input x: "))
y=int(input("Input y: "))
z=int(input("Input z: "))
print((x<y)or(not(z==y)and (z<x)))