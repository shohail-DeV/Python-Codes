package Stack;

import java.util.Scanner;

public class TestLinkedlist {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		A6_LinkedListStack l1= new A6_LinkedListStack();
		l1.display();
		int num;
		while(true) {
			System.out.println("*********MENU*****");
			System.out.println("0. Exit");
			System.out.println("1. Display");
			System.out.println("2. Push");
			System.out.println("3. Pop");
			System.out.println("Enter Your choice");
			num=sc.nextInt();
			switch(num)
			{
			case 0:
				return;
			case 1:l1.display();
		break;
			case 2:
			System.out.println("Enter info ");
			int ele=sc.nextInt();
			l1.push(ele);
			break;
			case 3:l1.pop();
			break;
			default:System.out.println("Wrong Choice");
			break;
		}
			}}
}
