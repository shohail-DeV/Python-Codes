package Stack;

public class Node {
	int info;
		Node link;
			}

