def fun(a=0, b=1):
    return (a**2 + b**2)
# print(fun(2,a=3)
# ,fun(b=3,2)
# ,fun(3,b=2)
# ,fun(a=4,5))