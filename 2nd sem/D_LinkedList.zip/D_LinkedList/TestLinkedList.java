package D_LinkedList;

import java.util.Scanner;
public class TestLinkedList {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	LinkedList l1= new LinkedList();
	l1.create();
	l1.display();
	int num;
	while(true) {
		System.out.println("*********MENU*****");
		System.out.println("0. Exit");
		System.out.println("1. Display");
		System.out.println("2. Count");
		System.out.println("3. Search");
		System.out.println("4. InsBeg");
		System.out.println("5. InsEnd");
		System.out.println("6. InsAny");
		System.out.println("7. delBeg");
		System.out.println("8. delEnd");
		System.out.println("9. delAny");
		System.out.println("10. Reverse");
		System.out.println("11. Sorting");
		System.out.println("12. Merge");
		System.out.println("Enter Your choice");
		num=sc.nextInt();
		switch(num)
		{
	case 0:return;
	case 1:l1.display();
	break;
	case 2:int c1=l1.count();
	System.out.println("Number of nodes ="+c1);
	break;
	case 3:System.out.println("Enter element to search");
	       int ele=sc.nextInt();
	       Node x=l1.search(ele);
	       if(x==null)
	    	   System.out.println("Element Not Found");
	       else
	    	   System.out.println("Element Found at Reference"+x);
	       break;
	case 4:l1.insBeg();
	       break;
	case 5:l1.insEnd();
	break;
	case 6:l1.insAny();
	break;
	case 7:l1.delBeg();
	break;
	case 8:l1.delEnd();
	break;
	case 9:l1.delAny();
	break;

	default:System.out.println("Wrong Choice");
		break;

	      
		}
	}
}}