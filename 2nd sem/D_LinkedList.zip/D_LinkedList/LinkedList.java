package D_LinkedList;

import java.util.Scanner;

public class LinkedList {
	Node start;
	Node end;
	Scanner sc = new Scanner(System.in);

	void create() {
		Node p = new Node();
		System.out.println("Input node value");
		p.info = sc.nextInt();
		p.link = p.prev = null;
		start = end = p;
		System.out.println("Do you want to add more node(1/0)");
		int op = sc.nextInt();
		while (op != 0) {
			Node q = new Node();
			System.out.println("Input node value");
			q.info = sc.nextInt();
			q.link = q.prev = null;
			p.link = q;
			q.prev = p;
			end = q;
			p = q;
			System.out.println("Do you want to add more node(1/0)");
			op = sc.nextInt();
		}
	}

	void display() {
		System.out.println("Forward Traversing");
		System.out.println("Start=" + start);
		Node p = start;
		while (p != null) {
			System.out.println(p.info + " " + p.link);
			p = p.link;
		}
		System.out.println("Backward Traversing");
		System.out.println("end=" + end);
		Node q = end;
		while (q != null) {
			System.out.println((q.prev + " " + q.info + " " + q.link));
			q = q.prev;
		}
	}

	int count() {
		Node p = start;
		int c = 0;
		while (p != null) {
			c++;
			p = p.link;
		}
		return c;
	}

	Node search(int ele) {
		Node p = start;
		while (p != null) {
			if (p.info == ele)
				return p;
			p = p.link;
		}
		return null;
	}

	void insBeg() {
		Node p = new Node();
		System.out.println("Input Node Value");
		p.info = sc.nextInt();
		if (start == null && end == null)
			start = end = p;// p.link=null;
							// start=end=p;
		else {
			p.link = start;//
			start.prev = p;
			start = p;
			start.prev = null;
		}
	}

	void insEnd() {
		Node p = new Node();
		System.out.println("Input Node Value");
		p.info = sc.nextInt();
		if (start == null && end == null)
			start = end = p;
		else {
			p.prev = end;
			end.link = p;
			end = p;
			p.link = null;
		}

	}

	void insAny() {
		int c = count();
		System.out.println("Input Position");
		int pos = sc.nextInt();
		if (pos < 1 || pos > c + 1)
			System.out.println("Insertion Not Possible");
		else {
			if (pos == 1)
				insBeg();
			else if (pos == c + 1)
				insEnd();
			else {
				Node p = new Node();
				System.out.println("Input Node Value");
				p.info = sc.nextInt();
				p.link = p.prev = null;
				int i = 1;
				Node q = start;
				while (i < pos - 1) {
					i++;
					q = q.link;
				}
				p.link = q.link;
				q.link = p;
				q.link = p;
				p.prev = q;
			}
		}
	}

	void delBeg() {
		if (start == null && end == null) {
			System.out.println("Underflow");

		} else if (start.link == null) {
			start = end = null;
		} else {
			Node p = start;
			start = start.link;
			p.link = null;
		}
	}

	void delEnd() {
		if (start == null && end == null) {
			System.out.println("Underflow");

		} else if (start.link == null)
			start = end = null;
		else {
			Node p = start;
			end = end.prev;
			end.link = null;
			p.prev = null;
		}
	}

	void delAny() {
		if (start == null && end == null) {
			System.out.println("Underflow");
		}	int c = count();
		
		System.out.println("Input Position");
		int pos = sc.nextInt();
		if (pos < 1 || pos > c) {
			System.out.println("Deletion not Possible");
		} else {
			if (pos == 1)
				delBeg();
			if (pos == c)
				delEnd();
			else {
				int i = 1;
				Node q = start;
				while (i < pos - 1) {
					i++;
					q = q.link;
				}
				Node p = q.link;
				q.link = q.link.link;
				q.link.prev = q;
				p.link = p.prev = null;
			}
		}
	}

}