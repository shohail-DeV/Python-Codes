def nMultiple(a = 0, num = 1):
    return a*num
print(nMultiple(5))
print(nMultiple(5,6))
print(nMultiple(num = 7))
print(nMultiple(num = 6, a = 5))
print(nMultiple(5, num = 6))