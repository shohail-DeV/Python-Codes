x = -5
def display(x):
    print(x)
    x = 5
    print(x)
display(x)
print(x)